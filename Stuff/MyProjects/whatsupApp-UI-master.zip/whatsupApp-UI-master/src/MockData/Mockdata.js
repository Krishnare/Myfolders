const mock = {
  Chats:['Msd', 'Bachpan', 'OfficeGroup', 'OfficeGroupWithoutManager', 'CricketLovers', 'mom', 'grandMaa', 'papa', 'mama', 'mami', 'pavan', 'sagar', 'yashu', 'murali', 'keerthi'],
  Calls: ['mom', 'grandMaa', 'papa', 'mama', 'mami', 'pavan', 'sagar', 'yashu', 'murali', 'keerthi'],
  Status: ['mom', 'mama', 'mami', 'pavan', 'sagar', 'yashu', 'murali'],
};

export default mock;
