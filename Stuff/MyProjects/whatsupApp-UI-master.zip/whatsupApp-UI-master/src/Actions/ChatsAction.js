import { LOAD_CHAT_INFO } from '../Constants/constants';

export function loadChatInfo(){
  return {
    type: LOAD_CHAT_INFO
  };
}
