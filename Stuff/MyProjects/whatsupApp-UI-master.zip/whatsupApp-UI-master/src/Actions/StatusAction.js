import { LOAD_STATUS_INFO } from '../Constants/constants';

export function loadStatusInfo(){
  return {
    type: LOAD_STATUS_INFO
  };
}
