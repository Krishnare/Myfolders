import { LOAD_CALLS_INFO } from '../Constants/constants';

export function loadCallsInfo(){
  return {
    type: LOAD_CALLS_INFO
  };
}
