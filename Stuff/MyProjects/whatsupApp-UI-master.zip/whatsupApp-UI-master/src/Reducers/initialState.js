export default {
  isFailed: false,
  isLoading: true,
  calls: undefined,
  status: undefined,
  chats: undefined,
};
